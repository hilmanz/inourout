
/* Custom Scripts */
$(document).ready(function() { 
	$('#countdown_dashboard').countDown({
		targetDate: {
			'day': 		15,
			'month': 	3,
			'year': 	2014,
			'hour': 	0,
			'min': 		0,
			'sec': 		0
		}
	});
});
